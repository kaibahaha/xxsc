#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""交错测试阅卷：分析 sandbox_cron_test.log，输出准时度/间隔/沙箱一致性报告"""
import re, sys
from datetime import datetime
LOG = "/workspace/sandbox_cron_test.log"
PLAN = {"T1": "08:40", "T2": "09:00", "T3": "09:20", "T4": "09:40"}

def main():
    try:
        lines = [l.strip() for l in open(LOG, encoding="utf-8") if l.strip()]
    except FileNotFoundError:
        print("日志不存在：/workspace/sandbox_cron_test.log —— 4 个任务可能一次都没跑成")
        return
    runs = {}
    for l in lines:
        m = re.match(r"(\S+ \S+)\s*\|\s*(T\d)\s*\|\s*(\S+)", l)
        if m:
            runs.setdefault(m.group(2), []).append((datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"), m.group(3)))
    if not runs:
        print("日志存在但无可解析记录，原文：")
        for l in lines[:10]: print(" ", l)
        return
    print(f"{'任务':<5}{'实际执行时刻':<22}{'计划':<8}{'偏差':<10}{'沙箱hostname'}")
    print("-" * 70)
    hosts = set()
    for t in ("T1", "T2", "T3", "T4"):
        if t not in runs:
            print(f"{t:<5}{'—— 未出现 ——'}")
            continue
        ts, host = runs[t][0]
        hosts.add(host)
        ph, pm = PLAN[t].split(":")
        plan_dt = ts.replace(hour=int(ph), minute=int(pm), second=0)
        dev = (ts - plan_dt).total_seconds()
        dev_s = f"{dev:+.0f}s" if abs(dev) < 120 else f"{dev/60:+.1f}min"
        print(f"{t:<5}{ts.strftime('%m-%d %H:%M:%S'):<22}{PLAN[t]:<8}{dev_s:<10}{host}")
    print("-" * 70)
    print(f"沙箱一致性：{'✅ 4 次同一沙箱（复用）' if len(hosts)==1 else f'⚠️ {len(hosts)} 个不同沙箱（每次新建）—— 长期任务必须只靠 /workspace 传状态'}")
    seq = [runs[t][0][0] for t in ("T1","T2","T3","T4") if t in runs]
    if len(seq) >= 2:
        gaps = [(seq[i+1]-seq[i]).total_seconds()/60 for i in range(len(seq)-1)]
        print(f"实际间隔：{' → '.join(f'{g:.1f}min' for g in gaps)}（设计值 20min）")
    print(f"总记录数：{sum(len(v) for v in runs.values())}（应=4，多出说明有重复触发）")

if __name__ == "__main__":
    main()
