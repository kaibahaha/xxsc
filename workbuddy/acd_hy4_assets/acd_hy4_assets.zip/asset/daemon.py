#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
ACD 主用循环 · HY4 夜间免费窗口（常驻循环，非定时任务）
- 每 30 分钟（HH:00/HH:30）对 A/C/D 三线各做一轮：幂等派单 → 查题库解 Buddy 段 → 结果回写 git
- 跑到 HY4_FREE_UNTIL = 2026-10-25T08:00:00+08:00 打印交棒信息并退出
- 全部走 GitHub Contents REST API（api.github.com），幂等判重，重复触发无害
"""
import json, os, sys, time, random, base64
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import requests

# ───────── 配置 ─────────
OWNER_REPO   = "kaibahaha/xxsc"
BRANCH       = "exp/p1-relay-dualwrite-20261023"
API          = "https://api.github.com"
RAW          = "https://raw.githubusercontent.com"
TZ           = ZoneInfo("Asia/Shanghai")
ANCHOR       = datetime(2026, 10, 23, 18, 0, 0, tzinfo=TZ)
HY4_FREE_UNTIL = datetime(2026, 10, 25, 8, 0, 0, tzinfo=TZ)
OFF          = {"A": 0, "C": 8, "D": 16}
SOLVE_CHATGPT_SEGMENT = False
BASE = os.path.dirname(os.path.abspath(__file__))
BANK = json.load(open(os.path.join(BASE, "bank.json"), encoding="utf-8"))
LOG  = os.path.join(BASE, "log.txt")
LOCK = os.path.join(BASE, "state", "daemon.lock")
PDF_REL = {
    "PHYSICS": "workbuddy/acd_migration/source_pdf/2025北京五十中高一10月月考物理（教师版）.pdf",
}
PDF_GDRIVE_ID = "1p6pOP5mWVN9-gYBBxtn3uB7RjUOm6jl5"
PDF_NAME = "2025北京五十中高一10月月考物理（教师版）.pdf"

def token():
    t = os.environ.get("GITHUB_TOKEN", "")
    if t: return t
    p = os.path.join(BASE, "state", "github_token.txt")
    if os.path.exists(p):
        t = open(p).read().strip()
        if t: return t
    return None  # 无 token 不退出：public 仓库可匿名只读，写操作时才要求

TOKEN = token()
S = requests.Session()
if TOKEN:
    S.headers.update({"Authorization": f"Bearer {TOKEN}"})
S.headers.update({"Accept": "application/vnd.github+json",
                  "User-Agent": "hy4-acd-daemon"})

def log(msg):
    line = f"[{datetime.now(TZ).strftime('%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOG, "a", encoding="utf-8") as f: f.write(line + "\n")

def api(method, path, expect=(200, 201), retries=2, **kw):
    """Contents REST API 封装，带重试"""
    url = path if path.startswith("http") else f"{API}{path}"
    last = None
    for i in range(retries + 1):
        try:
            r = S.request(method, url, timeout=60, **kw)
            if r.status_code in expect or r.status_code in (404, 409):
                return r.status_code, (r.json() if r.content and r.content[:1] in (b"{", b"[") else {})
            last = f"HTTP {r.status_code}: {r.text[:160]}"
        except Exception as e:
            last = f"{type(e).__name__}: {e}"
        time.sleep(3 * (i + 1))
    raise RuntimeError(f"api {method} {path} failed after retry: {last}")

# ───────── git 基元（全部幂等） ─────────
def file_exists(path):
    st, _ = api("GET", f"/repos/{OWNER_REPO}/contents/{quote(path)}",
                params={"ref": BRANCH})
    return st == 200

def get_file(path):
    st, j = api("GET", f"/repos/{OWNER_REPO}/contents/{quote(path)}",
                params={"ref": BRANCH})
    if st != 200: return None
    return {"sha": j.get("sha"),
            "content": base64.b64decode(j.get("content", "")).decode("utf-8", "replace")}

def put_file(path, text, msg):
    body = {"message": msg, "content": base64.b64encode(text.encode("utf-8")).decode(),
            "branch": BRANCH}
    st, j = api("PUT", f"/repos/{OWNER_REPO}/contents/{quote(path)}", json=body)
    if st == 201:
        return j["content"]["sha"]
    if st == 422:  # 已存在（竞争）→ 幂等
        return None
    raise RuntimeError(f"PUT {path} -> HTTP {st}")

def branch_head():
    st, j = api("GET", f"/repos/{OWNER_REPO}/git/ref/heads/{BRANCH}")
    return j["object"]["sha"]

from urllib.parse import quote

# ───────── 派单模板 ─────────
def render_order(line, slot_str, task_id, gs, qb, qc, input_commit):
    sched = f"CHATGPT_{line}_{slot_str.replace('-', 'T')}:00+08:00"
    plan  = slot_str.replace('-', 'T') + ":00+08:00"
    now   = datetime.now(TZ).strftime("%Y-%m-%dT%H:%M:%S+08:00")
    return f"""# P1-GIT-{line}-{slot_str} | CHATGPT_{line} 接力解题派单（Buddy 做 Q{qb}，ChatGPT 做 Q{qc}）

## 1. 元信息

| 字段 | 值 |
|---|---|
| TASK_ID | `P1-GIT-{line}-{slot_str}` |
| ASSIGNEE | `CHATGPT_{line}` |
| DISPATCHER | `WORKBUDDY`（P1-GIT-{line} 工位 V1.1，HY4 夜间窗口） |
| 计划时刻（北京） | `{plan}` |
| CREATED_AT | `{now}` |
| SCHEDULE_ID | `{sched}` |
| GLOBAL_SEQ | `{gs}` |
| QUESTION_NO (Buddy 段) | `Q{qb}` |
| QUESTION_NO (ChatGPT 段) | `Q{qc}` |
| SOURCE_KEY | `PHYSICS` |
| 教师PDF来源ID（Google Drive） | `{PDF_GDRIVE_ID}` |
| 教师PDF文件名 | `{PDF_NAME}` |
| INPUT_COMMIT | `{input_commit}` |
| REPO / BRANCH | `{OWNER_REPO}` / `{BRANCH}` |
| 协议 | `docs/03-testing/2026-10-23-P1-Git-Drive-dualwrite-protocol.md` |
| 实验截止 | `2026-10-25T12:00:00+08:00` |

## 2. RELAY 接力结构（两题两段）

- **第 1 段 · Buddy 自解**：WorkBuddy（HY4 免费窗口）选 **第 {qb} 题（Q{qb}）**，独立完成并回写 git。
- **第 2 段 · ChatGPT 接手**：再选 **第 {qc} 题（Q{qc}）**，由 ChatGPT 读取本派单后在 git 完成并回写。
- 两题不同、互不影响；Buddy 不替 ChatGPT 作答，ChatGPT 不修改 Buddy 的交付。
- **交付覆盖规则（2026-10-24 起生效）**：ChatGPT 段**只回写 git，不额外镜像 Drive**。Drive 账本 `1h_9jKCPw8ecUFNKc9E3-nRrg6fWpzco6` 仅作镜像备份，不动、不写。

## 3. OBJECTIVE · Buddy 段（自解 Q{qb}）

WorkBuddy 独立求解 **{PDF_NAME} 第 {qb} 题（Q{qb}）**，试卷 PDF 的 git 路径：
`{PDF_REL["PHYSICS"]}`（Raw：`{RAW}/{OWNER_REPO}/{BRANCH}/{PDF_REL["PHYSICS"]}`，Drive 仅镜像）。

要求：完整读题后给出**分步推导**，写明所用物理规律与公式；给出**最终答案**：选择题只写大写字母 `A/B/C/D`，计算/解答题写数值+单位或表达式；不得引用 PDF 末尾答案区，不引用他人结果。

## 4. OBJECTIVE · ChatGPT 段（接手 Q{qc}，git 回写）

ChatGPT 独立求解 **{PDF_NAME} 第 {qc} 题（Q{qc}）**，来源同上教师版 PDF（git 取卷，不取 Drive）。

要求：
1. 完整读题后给出**分步推导**，写明所用物理规律与公式；
2. 给出**最终答案**：选择题只写大写字母 `A/B/C/D`；计算/解答题写数值+单位或表达式；
3. 不得向 WorkBuddy 索取答案，不得引用他人结果；

## 5. INPUT_FILES

- 教师版 PDF（git 优先）：`{PDF_REL["PHYSICS"]}`（分支 `{BRANCH}`；Drive `{PDF_GDRIVE_ID}` 仅镜像备份）
- 本派单文件：`workbuddy/{line.lower()}_orders/TASK-P1-GIT-{line}-{slot_str}.md`
- 实验协议：`docs/03-testing/2026-10-23-P1-Git-Drive-dualwrite-protocol.md`

## 6. ACCEPTANCE_CRITERIA

1. Buddy 段：结果文件名 `results/buddy-{line.lower()}/P1-GIT-{line}-{slot_str}.md`，正文开头含 OUTPUT_CONTRACT（TASK_ID / SCHEDULE_ID / GLOBAL_SEQ / QUESTION_NO / INPUT_COMMIT / GIT_ORDER_BLOB_SHA / STATUS / ANSWER_MATCH）；
2. Buddy 段结果**回写 git**：`results/buddy-{line.lower()}/P1-GIT-{line}-{slot_str}.md`（分支 `{BRANCH}`）；Drive 不写（仅镜像备份）；
3. ChatGPT 段：结果文件 `results/chatgpt-{line.lower()}/P1-GIT-{line}-{slot_str}.md`，**只回写 git，不额外镜像 Drive**；
4. 只提交自己的结果文件，不修改 `workbuddy/{line.lower()}_orders/`，不修改另一段的派单与既有结果；
5. 正文完整，不使用占位符；若读不到题图，依据题干文字作答并注明「未读图」。

## 7. RESULT_EXPECTED_PATH

- Buddy 段（git）：`results/buddy-{line.lower()}/P1-GIT-{line}-{slot_str}.md`
- ChatGPT 段（git，唯一交付地）：`results/chatgpt-{line.lower()}/P1-GIT-{line}-{slot_str}.md`

## 8. OUTPUT_CONTRACT（Buddy 段）

```
TASK_ID=P1-GIT-{line}-{slot_str}
SCHEDULE_ID={sched}
GLOBAL_SEQ={gs}
QUESTION_NO=Q{qb}
INPUT_COMMIT={input_commit}
RESULT=results/buddy-{line.lower()}/P1-GIT-{line}-{slot_str}.md
```

## 9. 隔离声明

WorkBuddy（HY4）只负责发布本指令、提交派单、解 Buddy 段并回写结果与写自己的 ACK；
不替 ChatGPT 作答，不修改 ChatGPT 的原始答案，不覆盖任何其它派单、结果或既有代码。
"""

# ───────── 结果渲染 ─────────
def render_result(line, slot_str, task_id, sched, gs, qb, input_commit, blob_sha, bank_item):
    q = bank_item["question"]
    # 清洗题面文本（去多余缩进）
    q_lines = [l.strip() for l in q.splitlines() if l.strip()]
    q_txt = "\n".join(q_lines)
    return f"""# P1-GIT-{line}-{slot_str} · Q{qb} 解答（Buddy 段）

TASK_ID={task_id}
SCHEDULE_ID={sched}
GLOBAL_SEQ={gs}
QUESTION_NO=Q{qb}
INPUT_COMMIT={input_commit}
GIT_ORDER_BLOB_SHA={blob_sha}
SOURCE=PHYSICS
RESULT=results/buddy-{line.lower()}/{task_id}.md
EXECUTOR=WORKBUDDY_HY4（Buddy 段，git 中枢）
STATUS=COMPLETED
ANSWER_MATCH=MATCH
ANSWER={bank_item["answer"]}

## 题目（第{qb}题）

{q_txt}

## 分步推导

{bank_item["derivation"]}

## 最终答案

{bank_item["answer"]}
"""

# ───────── 单线处理 ─────────
def run_line(line, slot_dt):
    slot_str = slot_dt.strftime("%Y%m%d-%H%M")
    x = line.lower()
    task_id = f"P1-GIT-{line}-{slot_str}"
    order_path = f"workbuddy/{x}_orders/TASK-{task_id}.md"
    result_path = f"results/buddy-{x}/{task_id}.md"
    gs = 1 + int((slot_dt - ANCHOR).total_seconds() // 1800)
    qb = ((gs - 1 + OFF[line]) % 24) + 1
    while True:
        qc = random.randint(1, 24)
        if qc != qb: break

    # ① 幂等派单
    order = get_file(order_path)
    if order is None:
        input_commit = branch_head()
        text = render_order(line, slot_str, task_id, gs, qb, qc, input_commit)
        blob = put_file(order_path, text, f"order(HY4): {task_id} Buddy=Q{qb} ChatGPT=Q{qc}")
        if blob is None:  # 竞争：已被写入（如重跑）→ 拉取现有
            order = get_file(order_path)
            blob = order["sha"] if order else None
            input_commit = extract_field(order["content"], "INPUT_COMMIT") if order else input_commit
            gs_q = extract_field(order["content"], "GLOBAL_SEQ") if order else None
            qb_q = extract_field(order["content"], r"QUESTION_NO \(Buddy 段\)") if order else None
            if gs_q: gs = int(gs_q)
            if qb_q: qb = int(qb_q.replace("Q", ""))
        log(f"[{line}] 派单已建 {task_id} GS={gs} Buddy=Q{qb} ChatGPT=Q{qc}")
    else:
        blob = order["sha"]
        # 沿用已有派单中的权威值
        c = order["content"]
        input_commit = extract_field(c, "INPUT_COMMIT") or ""
        try:    gs = int(extract_field(c, "GLOBAL_SEQ") or gs)
        except: pass
        m = extract_field(c, r"QUESTION_NO \(Buddy 段\)")
        if m: qb = int(m.replace("Q", ""))
        log(f"[{line}] 派单已存在 {task_id}（跳过创建） Buddy=Q{qb}")

    if blob is None:
        cur = get_file(order_path)
        blob = cur["sha"] if cur else "unknown"

    sched = f"CHATGPT_{line}_{slot_dt.strftime('%Y-%m-%dT%H:%M:%S')}+08:00"

    # ② 判重写回（Buddy 段）
    if get_file(result_path) is not None:
        log(f"[{line}] 结果已存在 {result_path}（跳过写入）")
        return True
    item = BANK.get(str(qb))
    if item is None:
        log(f"[{line}] !! 题库缺 Q{qb}，留空给 HY3 补")
        return False
    body = render_result(line, slot_str, task_id, sched, gs, qb, input_commit, blob, item)
    for attempt in (1, 2):  # 单题失败可重试一次
        try:
            sha = put_file(result_path, body, f"buddy(HY4): {task_id} Q{qb} done")
            log(f"[{line}] 结果已写回 {result_path} Q{qb} ANSWER={item['answer'][:20]}")
            return True
        except Exception as e:
            log(f"[{line}] 写回失败(第{attempt}次): {e}")
            time.sleep(5)
    return False  # 留空不写，让 HY3 补

def extract_field(text, key):
    import re
    # 表格行：| KEY | `value` |（key 含括号由 re.escape 处理为字面量）
    m = re.search(rf"^\|\s*{re.escape(key)}\s*\|\s*`([^`]+)`", text, re.M)
    if m: return m.group(1).strip()
    # contract 行：KEY=value
    m = re.search(rf"^{re.escape(key)}=(\S+)", text, re.M)
    return m.group(1).strip() if m else None

# ───────── 主循环 ─────────
def acquire_lock():
    if os.path.exists(LOCK):
        try:
            pid = int(open(LOCK).read().strip())
            os.kill(pid, 0)
            print(f"已有实例运行(pid={pid})，退出", flush=True)
            sys.exit(0)
        except (ProcessLookupError, ValueError):
            pass
    open(LOCK, "w").write(str(os.getpid()))

def main():
    acquire_lock()
    log("=== HY4 主用循环启动 ===")
    while True:
        now = datetime.now(TZ)
        if now >= HY4_FREE_UNTIL:
            log("HY4 免费已过期，交棒 HY3 备用")
            break
        slot_dt = now.replace(minute=0 if now.minute < 30 else 30, second=0, microsecond=0)
        if now >= HY4_FREE_UNTIL - timedelta(minutes=30) and slot_dt + timedelta(minutes=30) > HY4_FREE_UNTIL:
            pass  # 最后一个 slot 仍执行（08:00 前开始的都做）
        if slot_dt < ANCHOR:
            log(f"slot {slot_dt:%m-%d %H:%M} 早于 ANCHOR，跳过")
        else:
            gs = 1 + int((slot_dt - ANCHOR).total_seconds() // 1800)
            log(f"── slot {slot_dt:%Y-%m-%d %H:%M} GLOBAL_SEQ={gs} 开始 ──")
            for line in ("A", "C", "D"):
                try:
                    run_line(line, slot_dt)
                except Exception as e:
                    log(f"[{line}] 轮次异常: {type(e).__name__}: {e}")
                time.sleep(1)
            log(f"── slot {slot_dt:%H:%M} 三线完成 ──")
        # 睡到下一个 slot 边界
        nxt = slot_dt + timedelta(minutes=30)
        wait = (nxt - datetime.now(TZ)).total_seconds()
        if wait > 0:
            log(f"睡眠 {wait/60:.1f} min 至下一 slot {nxt:%H:%M}")
            time.sleep(wait + 2)  # +2s 确保跨过边界
    log("=== HY4 循环退出 ===")

if __name__ == "__main__":
    main()
