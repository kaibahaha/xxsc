#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
漏格补齐 v2 —— 支持无参自动模式（供云端定时任务无人值守调用）
用法：
  python3.11 backfill.py                 # 自动模式：补齐 state/last_ok 之后到当前 slot 的全部漏格
  python3.11 backfill.py 20261025-0800   # 指定 slot（旧行为，保留）
  python3.11 backfill.py --dry-run       # 自动模式试跑：只列计划，不写 git
  python3.11 backfill.py --dry-run 20261025-0800
规则：
  - 起点 = git 三个 results/buddy-{a,c,d} 目录中最新结果格的最旧者 + 30min（无状态，不依赖本地游标）
  - git 完全无结果时，从今天 00:00 开始
  - 终点 = 当前北京时间向下取整到 30 分钟边界（不含未来 slot）
  - 单次最多补 48 格（24 小时），超出部分留下一轮
  - 写操作需要 token；无 token 时匿名只读：能算计划、能报漏格，写时明确报错退出码仍为 0
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import daemon
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
TZ = daemon.TZ
STATE = os.path.join(daemon.BASE, "state", "last_ok.txt")
MAX_CATCHUP = 48

def latest_slot_from_git():
    """扫三个 buddy 结果目录取各自最新 slot，返回最旧者（保守起点）——无状态自举"""
    import re
    lats = []
    for x in ("a", "c", "d"):
        try:
            st, j = daemon.api("GET", f"/repos/{daemon.OWNER_REPO}/contents/results/buddy-{x}",
                               params={"ref": daemon.BRANCH})
        except Exception as e:
            daemon.log(f"[backfill] 列目录 results/buddy-{x} 失败: {e}")
            continue
        if st == 200 and isinstance(j, list):
            slots = [m.group(1) for f in j
                     if (m := re.match(r"P1-GIT-[ACD]-(\d{8}-\d{4})\.md$", f.get("name", "")))]
            if slots:
                lats.append(max(slots))
    return min(lats) if lats else None

def auto_slots():
    now = datetime.now(TZ)
    cur = now.replace(minute=0 if now.minute < 30 else 30, second=0, microsecond=0)
    lat = latest_slot_from_git()
    if lat:
        start = datetime.strptime(lat, "%Y%m%d-%H%M").replace(tzinfo=TZ) + timedelta(minutes=30)
        src = f"git最新结果格 {lat}"
    else:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        src = "git无结果，从今天00:00起"
    slots, s = [], start
    while s <= cur and len(slots) < MAX_CATCHUP:
        slots.append(s.strftime("%Y%m%d-%H%M")); s += timedelta(minutes=30)
    daemon.log(f"[backfill] 起点来源：{src}；终点 {cur:%Y%m%d-%H%M}")
    return slots

def main():
    args = list(sys.argv[1:])
    dry = "--dry-run" in args
    args = [a for a in args if not a.startswith("--")]
    if args:
        slots = args
        daemon.log(f"[backfill] 指定模式 slots={slots}")
    else:
        slots = auto_slots()
        daemon.log(f"[backfill] 自动模式 计划 {len(slots)} 格: "
                   f"{slots[0] if slots else '无'} → {slots[-1] if slots else '无'}")
    if not slots:
        daemon.log("[backfill] 无漏格，退出")
        return
    if dry:
        for sl in slots:
            print(f"[dry-run] 将处理 {sl} × A/C/D")
        return
    ok = 0
    for sl in slots:
        dt = datetime.strptime(sl, "%Y%m%d-%H%M").replace(tzinfo=TZ)
        for line in ("A", "C", "D"):
            try:
                if daemon.run_line(line, dt): ok += 1
            except Exception as e:
                daemon.log(f"[backfill {line}-{sl}] 异常: {type(e).__name__}: {e}")
    daemon.log(f"[backfill] 本轮完成：{len(slots)} slot，写回 {ok} 格")
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    open(STATE, "w").write(slots[-1])

if __name__ == "__main__":
    main()
