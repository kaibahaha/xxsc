#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
漏格补齐 v2 —— 支持无参自动模式（供云端定时任务无人值守调用）
用法：
  python3.11 backfill.py                 # 自动模式：补齐 state/last_ok 之后到当前 slot 的全部漏格
  python3.11 backfill.py 20261025-0800   # 指定 slot（旧行为，保留）
  python3.11 backfill.py --dry-run       # 自动模式试跑：只列计划，不写 git
  python3.11 backfill.py --dry-run 20261025-0800
规则：
  - 起点 = max(state/last_ok.txt + 30min, 今天 00:00)；无 last_ok 则从今天 00:00 开始
  - 终点 = 当前北京时间向下取整到 30 分钟边界（不含未来 slot）
  - 单次最多补 48 格（24 小时），超出部分留下一轮
  - 全部 slot 都处理完（含幂等跳过）才把终点写回 state/last_ok.txt
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import daemon
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
TZ = daemon.TZ
STATE = os.path.join(daemon.BASE, "state", "last_ok.txt")
MAX_CATCHUP = 48

def auto_slots():
    now = datetime.now(TZ)
    cur = now.replace(minute=0 if now.minute < 30 else 30, second=0, microsecond=0)
    start = None
    if os.path.exists(STATE):
        try:
            start = datetime.strptime(open(STATE).read().strip(), "%Y%m%d-%H%M").replace(tzinfo=TZ) + timedelta(minutes=30)
        except ValueError:
            start = None
    if start is None:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    slots, s = [], start
    while s <= cur and len(slots) < MAX_CATCHUP:
        slots.append(s.strftime("%Y%m%d-%H%M")); s += timedelta(minutes=30)
    return slots

def main():
    args = list(sys.argv[1:])
    dry = "--dry-run" in args
    args = [a for a in args if not a.startswith("--")]
    if args:
        slots = args
        daemon.log(f"[backfill] 指定模式 slots={slots}")
    else:
        slots = auto_slots()
        daemon.log(f"[backfill] 自动模式 计划 {len(slots)} 格: "
                   f"{slots[0] if slots else '无'} → {slots[-1] if slots else '无'}")
    if not slots:
        daemon.log("[backfill] 无漏格，退出")
        return
    if dry:
        for sl in slots:
            print(f"[dry-run] 将处理 {sl} × A/C/D")
        return
    ok = 0
    for sl in slots:
        dt = datetime.strptime(sl, "%Y%m%d-%H%M").replace(tzinfo=TZ)
        for line in ("A", "C", "D"):
            try:
                if daemon.run_line(line, dt): ok += 1
            except Exception as e:
                daemon.log(f"[backfill {line}-{sl}] 异常: {type(e).__name__}: {e}")
    daemon.log(f"[backfill] 本轮完成：{len(slots)} slot，写回 {ok} 格")
    open(STATE, "w").write(slots[-1])

if __name__ == "__main__":
    main()
